# Uppsala pyub

Use Uppsala University's library catalog from the command line or script searches by using this package as a module.

## installation

## Usage